package cliente;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente implements ActionListener {

    String hostName = "193.39.92.110";
    int portNumber = 4001;

    Socket cliente_servidor;
    PrintWriter out;
    BufferedReader in;
    
    String user;
    String fromServer;
    String fromUser;
    VistaLogin vista = new VistaLogin();
    DefaultTableModel modelo = new DefaultTableModel();
    Controlador controlador;

    public Cliente(VistaLogin vista) throws IOException {
        this.vista = vista;
        this.vista.btnIniciar.addActionListener(this);
        this.establecerConexion();
    }

    public void establecerConexion() throws IOException {
        cliente_servidor = new Socket(hostName, portNumber);
        out = new PrintWriter(cliente_servidor.getOutputStream(), true); // escritor
        in = new BufferedReader(new InputStreamReader(cliente_servidor.getInputStream())); // lector
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnIniciar) { // cuando pulse iniciar
            try {
                comunicarse();
            } catch (IOException ex) {
                Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
            }
            vista.txtContrasenia.setText("");
            vista.txtUsuario.setText("");
        }
    }

    public void comunicarse() throws IOException {
        String pwd;
        String[] respuesta;

        user = vista.txtUsuario.getText(); // obtengo usuario de la caja de texto
        pwd = String.copyValueOf(vista.txtContrasenia.getPassword()); // obtengo contraseña de la caja de texto

        out.println("PROTOCOLCRISTOPOP1.0#LOGIN#" + user + "#" + pwd); // envio al servidor
        fromServer = in.readLine(); // RESPUESTA DEL SERVIDOR
        respuesta = fromServer.split("#");

        if (fromServer.equals("PROTOCOLCRISTOPOP1.0#ERROR#BAD_LOGIN")) { // si es erroneo
            vista.textoVuelta.setVisible(true); // imprimo por interfaz
        } else {
            vista.textoVuelta.setVisible(false);
        }

        if ((respuesta[0]+"#"+respuesta[1]).equals("PROTOCOLCRISTOPOP1.0#WELLCOME")) { // si es correcto
            System.out.println("Usuario correcto"); // Imprimo debug
            this.vista.dispose(); // cierro ventana login
            this.controlador = new Controlador(cliente_servidor, out, in, user, respuesta[4]);
            controlador.extraerProductos();
        }
    }

}

// en el cliente tengo que instanciar la vista login
// cuando el servidor me devuelva la respuesta de que el login es correcto, en el propio cliente iniciaré la vista con la tabla y enviare solicitud
// rellenaré la tabla con los productos
// cuando pulse sobre cualquier fila iniciaré una nueva hebra con otra vista
// a esta hebra le tendre que pasar el socket (y puede que el buffered printwriter, y el producto) para que estas hebras puedan hacer peticiones por su cuenta
// si inicio otra hebra, esta puede hacer una peticion, pero lo que no debe hacer es recibir la informacion que devuelve el server a otra hebra del cliente
// con lo cual, si una segunda hebra se ha iniciado, y por defecto ha hecho una peticion, esta hebra será la siguiente en tener que recibir 
// , es decir, tendre que meter ha esta hebra en la cola de recepcion, similar al productor, consumidor
// en el momento que envie la peticion tambien haré una escucha para la respuesta del servidor y meter la hebra en la posicion de la cola adecuada
