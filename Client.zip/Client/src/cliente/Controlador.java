package cliente;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Controlador {

    Socket cliente_servidor;
    PrintWriter out;
    BufferedReader in;

    String fromServer;
    String fromUser;
    String user;
    String token;

    Mensaje producto;
    ArrayList<Mensaje> listaProductos = new ArrayList<Mensaje>();

    TablaProductos tabla = new TablaProductos();
    DefaultTableModel modelo = new DefaultTableModel();

    ArrayList<Thread> ventanaProducto = new ArrayList<Thread>();
    Object cerrojo = new Object();
    Object cerrojoComprar = new Object();

    public Controlador(Socket cliente_servidor, PrintWriter out, BufferedReader in, String user, String token) {
        this.cliente_servidor = cliente_servidor;
        this.out = out;
        this.in = in;
        this.user = user;
        this.token = token;
        abreProducto();
    }

    // metodo que inicia ventana con la tabla, cierra ventana del login, envia peticion al cliente, recibe respuesta de cliente
    public void extraerProductos() throws IOException {
        tabla.setVisible(true);
        out.println("PROTOCOLCRISTOPOP1.0#GET_PRODUCTS#" + user + "#" + token); // envio peticion
        fromServer = in.readLine(); // guardo el String productos que me ha enviado el servidor
        //System.out.println(fromServer); // debug
        insertaProductosEnArray(fromServer); // inserto productos en el array e productos
        imprimirProductos(tabla.tablaProductos);
    }

    // metodo imprime productos en la tabla
    public void imprimirProductos(JTable tabla) {
        modelo = (DefaultTableModel) tabla.getModel();
        Object[] object = new Object[3];
        for (int i = 0; i < listaProductos.size(); i++) {
            object[0] = listaProductos.get(i).getNombre();
            object[1] = listaProductos.get(i).getPrecio();
            object[2] = listaProductos.get(i).getVisualizaciones();
            modelo.addRow(object);
        }
        tabla.setModel(modelo);
    }

    // metodo que rellena el ArrayList de productos a partir del string mensaje
    public void insertaProductosEnArray(String mensaje) {
        // ejemplo mensaje PROTOCOLCRISTOPOP1.0#AVAILABLE_PRODUCTS#3#0001@FunkoPop@24@1#0002@Baston@2@3#0003@carro@100@94
        String[] mensajes = mensaje.split("#");
        int numeroProductos = Integer.parseInt(mensajes[2]);

        for (int i = 0; i < numeroProductos; i++) {
            String[] campo = mensajes[i + 3].split("@");
            Mensaje nuevoProducto = new Mensaje(campo[0], campo[1], Double.parseDouble(campo[2]), Integer.parseInt(campo[3]));
            listaProductos.add(nuevoProducto);
        }
    }

    public void abreProducto() {

        // tengo que crear un objeto que implemente runnable y pasarle el socket , out , in, tabla
        //ServidorActualizaTabla servidorActualizaTabla = new ServidorActualizaTabla(cliente_servidor, out, in, tabla);
        //ventanaProducto.add(new Thread(servidorActualizaTabla));
        //ventanaProducto.get((ventanaProducto.size() - 1)).start();

        MouseListener mListener = new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent e) {

                ControladorVentanaProducto controladorVentanaProducto = new ControladorVentanaProducto(cliente_servidor, out, in, listaProductos.get(tabla.tablaProductos.getSelectedRow()).getId_producto(), cerrojo, user, token, cerrojoComprar,ventanaProducto);
                ventanaProducto.add(new Thread(controladorVentanaProducto));
                ventanaProducto.get((ventanaProducto.size() - 1)).start();

                //System.out.println("Numero de fila: " + tabla.tablaProductos.getSelectedRow());
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }
        };

        tabla.tablaProductos.addMouseListener(mListener);
    }

}
