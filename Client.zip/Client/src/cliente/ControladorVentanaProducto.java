package cliente;

import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class ControladorVentanaProducto implements Runnable {

    VentanaProducto ventanaProducto = new VentanaProducto();

    Socket cliente_servidor;
    PrintWriter out;
    BufferedReader in;

    Object cerrojo;
    Object cerrojoComprar;
    String idProducto;
    String user;
    String token;
    String formato;

    String mensajeServidor;
    String respuestaCompra;
    String[] item;
    String[] bytes_sended;
    ArrayList<String> imagen_bs64 = new ArrayList<>();
    //String imagen_codificada = "";
    ArrayList<byte[]> b = new ArrayList<>();
    ArrayList<Thread> ventanaP;

    public ControladorVentanaProducto(Socket cliente_servidor, PrintWriter out, BufferedReader in, String idProducto, Object cerrojo, String user, String token, Object cerrojoComprar, ArrayList<Thread> ventanaProducto) {
        this.cliente_servidor = cliente_servidor;
        this.out = out;
        this.in = in;
        this.idProducto = idProducto;
        this.cerrojo = cerrojo;
        this.user = user;
        this.token = token;
        this.cerrojoComprar = cerrojoComprar;
        this.ventanaP=ventanaProducto;
        compraProducto(); //ejecuto para que al principio se cree el mouseListener
    }

    @Override
    public void run() {
        ventanaProducto.setDefaultCloseOperation(ventanaProducto.DISPOSE_ON_CLOSE);
        ventanaProducto.setVisible(true);

        synchronized (cerrojo) {
            /*
            try {
                ventanaP.get(0).wait(); // DUERMO HEBRA
            } catch (InterruptedException ex) {
                Logger.getLogger(ControladorVentanaProducto.class.getName()).log(Level.SEVERE, null, ex);
            }
            */
            try {
                out.println("PROTOCOLCRISTOPOP1.0#GET_ITEM#" + user + "#" + token + "#" + idProducto); // envio peticion
                // ejemplo mensajeServidor PROTOCOLCRISTOPOP1.0#GET_ITEM#<cod_prod>@<name>@<vendedor>@<price>@<visualizations>@<description>
                mensajeServidor = in.readLine();
            } catch (IOException ex) {
                Logger.getLogger(ControladorVentanaProducto.class.getName()).log(Level.SEVERE, null, ex);
            }

            item = mensajeServidor.split("#");
            String[] datosItem = item[2].split("@");
            //ventanaProducto.txtCodigoProducto.setText(datosItem[0]);
            ventanaProducto.txtNombreProducto.setText(datosItem[1]);
            ventanaProducto.txtVendedor.setText(datosItem[2]);
            ventanaProducto.txtPrecio.setText(datosItem[3]);
            ventanaProducto.txtVisualizaciones.setText(datosItem[4]);
            ventanaProducto.txtDescripcion.setText(datosItem[5]);
            formato = item[3];
            if (user.equals(datosItem[2])) {
                ventanaProducto.btnComprar.setVisible(false);
            }
            System.out.println("Formato: " + item[3] + " Tamaño: " + item[4]);

            try {

                out.println("PROTOCOLCRISTOPOP1.0#PREPARED_TO_RECEIVE#" + user + "#" + token + "#" + idProducto + "#SIZE_PACKAGE#512"); // envio peticion
                for (int i = 0; i < (Integer.parseInt(item[4]) / 512) + 1; i++) { // recibo mensaje x veces, y relleno arraylist
                    mensajeServidor = in.readLine();
                    bytes_sended = mensajeServidor.split("#");
                    byte[] decodedBytes = Base64.getDecoder().decode(bytes_sended[3]);
                    b.add(decodedBytes);
                }

                try {
                    //String path = ".\\";
                    Path path = Paths.get(datosItem[0] + "." + formato);
                    Files.deleteIfExists(path); // borro el archivo si existe

                    File file = new File(datosItem[0] + "." + formato);
                    FileOutputStream stream = new FileOutputStream(file, true);
                    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(stream);
                    for (byte[] a : b) {
                        bufferedOutputStream.write(a);
                    }
                    bufferedOutputStream.close();
                    stream.close();

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                Logger.getLogger(ControladorVentanaProducto.class.getName()).log(Level.SEVERE, null, e);
            }
            ImageIcon imagen = new ImageIcon(datosItem[0] + "." + formato);
            Icon icono = new ImageIcon(imagen.getImage().getScaledInstance(ventanaProducto.imagenLabel.getWidth(), ventanaProducto.imagenLabel.getHeight(), Image.SCALE_DEFAULT));
            ventanaProducto.imagenLabel.setIcon(icono);
            
            
        }
        //ventanaP.get(0).notify();
    }

    public void compraProducto() {
        MouseListener listenerBoton = new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                synchronized(cerrojoComprar){
                    try {
                        out.println("PROTOCOLCRISTOPOP1.0#BUY_PRODUCT#"+user+"#"+token+"#"+idProducto); // envio peticion
                        respuestaCompra = in.readLine();
                    } catch (IOException ex) {
                        Logger.getLogger(ControladorVentanaProducto.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }
        };
        
        ventanaProducto.btnComprar.addMouseListener(listenerBoton);
        
    }

}
