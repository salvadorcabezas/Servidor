package cliente;


public class Mensaje {
    
    String id_producto;
    String nombre;
    double precio; 
    int visualizaciones;

    public Mensaje(String id_producto, String nombre, double precio, int visualizaciones) {
        this.id_producto = id_producto;
        this.nombre = nombre;
        this.precio = precio;
        this.visualizaciones = visualizaciones;
    }

    public Mensaje() {
    }
    
    public String getId_producto() {
        return id_producto;
    }

    public void setId_producto(String id_producto) {
        this.id_producto = id_producto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getVisualizaciones() {
        return visualizaciones;
    }

    public void setVisualizaciones(int visualizaciones) {
        this.visualizaciones = visualizaciones;
    }
    
}
