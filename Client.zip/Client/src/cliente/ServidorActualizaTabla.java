package cliente;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServidorActualizaTabla implements Runnable {

    Socket cliente_servidor;
    PrintWriter out;
    BufferedReader in;
    TablaProductos tabla;
    String respuestaServidor;
    String[] mensaje;

    public ServidorActualizaTabla(Socket cliente_servidor, PrintWriter out, BufferedReader in, TablaProductos tabla) {
        this.cliente_servidor = cliente_servidor;
        this.in = in;
        this.out = out;
        this.tabla = tabla;
    }

    @Override
    public void run() {
        try {
            respuestaServidor = in.readLine();
            mensaje = respuestaServidor.split("#");
            
            if(mensaje[1].equals("BUY_ACCEPTED")){
                System.out.println("DEBUG: MENSAJE RECIBIDO, ACTUALIZANDO TABLA");
            } else{
                System.err.println("HE RECIBIDO UNA WEA CULERA QUE NO DEBÍA");
                System.out.println("DEBUG: " + respuestaServidor);
            }
        } catch (IOException ex) {
            Logger.getLogger(ControladorVentanaProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
