package Modelo;

public class modeloProducto {
    
}
